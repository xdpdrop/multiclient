import {
  test as base,
  expect,
  _electron as electron,
  type ElectronApplication,
  type Page,
} from '@playwright/test';
import { mkdtemp, mkdir, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';

export type DesktopFixture = {
  app: ElectronApplication;
  page: Page;
  data: string;
  addProject(name: string): Promise<string>;
  restart(): Promise<void>;
};
export const test = base.extend<{ desktop: DesktopFixture; developmentModes: boolean }>({
  developmentModes: [false, { option: true }],
  desktop: async ({ developmentModes }, use) => {
    const data = await mkdtemp(join(tmpdir(), 'multiclient-focused-e2e-'));
    const env = Object.fromEntries(
      Object.entries(process.env).filter(
        (entry): entry is [string, string] => entry[1] !== undefined,
      ),
    );
    delete env.ELECTRON_RUN_AS_NODE;
    delete env.MULTICLIENT_DEVELOPMENT_MODES;
    if (developmentModes) env.MULTICLIENT_DEVELOPMENT_MODES = '1';
    env.MULTICLIENT_TEST_MODE = '1';
    env.MULTICLIENT_TEST_DATA = data;
    const launch = () =>
      electron.launch({
        ...(process.env.MULTICLIENT_PACKAGED_PATH
          ? { executablePath: process.env.MULTICLIENT_PACKAGED_PATH, args: [] }
          : { args: [resolve('out/main/index.js')] }),
        env,
      });
    let app = await launch();
    try {
      let page = await app.firstWindow();
      await expect(page.getByRole('heading', { name: 'What’s next?' })).toBeVisible();
      await use({
        get app() {
          return app;
        },
        get page() {
          return page;
        },
        data,
        restart: async () => {
          await app.close();
          app = await launch();
          page = await app.firstWindow();
          await expect(page.getByRole('heading', { name: 'What’s next?' })).toBeVisible();
        },
        addProject: async (name) => {
          const path = join(data, name);
          await mkdir(path);
          await app.evaluate(({ dialog }, selected) => {
            dialog.showOpenDialog = async () => ({ canceled: false, filePaths: [selected] });
          }, path);
          await page.getByRole('button', { name: 'Add project', exact: true }).click();
          const id = await page.evaluate(
            async (selected) =>
              (await window.desktop.snapshot()).projects.find(
                (project) => project.path === selected,
              )!.id,
            path,
          );
          await page.evaluate((projectId) => window.desktop.trustProject(projectId, true), id);
          return id;
        },
      });
    } finally {
      await app.close();
      await rm(data, { recursive: true, force: true, maxRetries: 5, retryDelay: 200 });
    }
  },
});
export { expect };
export async function choose(page: Page, label: string, option: string) {
  await page.getByRole('combobox', { name: label, exact: true }).click();
  await page
    .getByRole('listbox', { name: label, exact: true })
    .getByRole('option', { name: option, exact: true })
    .click();
}

export function recordErrors(page: Page) {
  const errors: string[] = [];
  page.on('pageerror', (error) => errors.push(error.message));
  return errors;
}

export async function sendLocal(page: Page, text: string) {
  await choose(page, 'Provider', 'Local test provider');
  await page.getByLabel('Message', { exact: true }).fill(text);
  await page.getByRole('button', { name: 'Send message', exact: true }).click();
  await expect(
    page.locator('article[data-message-role="user"]').filter({ hasText: text }),
  ).toBeVisible();
  await expect(page.getByRole('button', { name: 'Stop response', exact: true })).toHaveCount(0);
}

export async function waitForShellPrompt(page: Page, outputKey: string, cwd: string) {
  const output = () =>
    page.evaluate(
      (key) => String((window as any)[key] ?? '').replace(/\x1b\[[0-?]*[ -/]*[@-~]/g, ''),
      outputKey,
    );
  if (process.platform === 'win32') await expect.poll(output).toContain(`PS ${cwd}>`);
  else await expect.poll(output).toMatch(/[$#>%]\s*$/);
}
